MessagePack for Erlang
======================
Binary-based efficient object serialization library.

see wiki ( http://redmine.msgpack.org/projects/msgpack/wiki/QuickStartErlang ) for details

# Status

0.1.0 released.
