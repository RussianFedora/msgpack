package org.msgpack;
/*
 * Created by IntelliJ IDEA.
 * User: takeshita
 * Date: 11/03/10
 * Time: 1:52
 */

class ScalaTemplateBuilder {


  def pack(v : Int) = {

  }

}