package org.msgpack;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestSample {
    @Test
    public void testNull() throws Exception {
        assertEquals("aiueo", 0, 0);
    }
};
